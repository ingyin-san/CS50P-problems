#prompts the user for input (in all CAPS) and outputs that same input in lowercase

print(input().lower())
