"""prompts the user for input and
outputs that same input, replacing each space with ... (i.e., three periods)"""

print(input().replace(" ", "..."))
